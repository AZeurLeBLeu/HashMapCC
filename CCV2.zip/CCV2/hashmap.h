#ifndef HASHMAP_H
#define HASHMAP_H

#include "common.h"

typedef struct HashMap {
    Arbre *pRoot;
    int size;
} HashMap;

HashMap *createHashMap();
int addHM(HashMap *head, char *key, int value);
Eleve *getHM(HashMap *head, char *key);
int removeHM(HashMap *head, char *key);
int sizeHM(HashMap *head);
int update(HashMap *head, char *key, int value);

#endif // HASHMAP_H
