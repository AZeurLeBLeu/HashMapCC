#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct Eleve {
    char *key;
    int value;
    struct Eleve* fils;
} Eleve;

typedef struct Arbre {
    int hash;
    Eleve *e;
    struct Arbre* fg;
    struct Arbre* fd;
} Arbre;

int HashCode (char *ligne);
Eleve *searchHM(Arbre *tree, int hash, char *key);
int addNode(Arbre **tree, char *key, int value, int hash);
int searchuHM(Arbre *tree, int hash, char *key, int value);
int searchrHM(Arbre *tree, int hash, char *key);
Eleve *searchArbre(Eleve *e, char *key);
Eleve *creationEleve(char *key, int value);
int freedomFile(Eleve *e);
void display(Arbre *head);
int updateArbre(Eleve *e, char *key, int value);
int displayFile(Eleve *e);
Eleve *removeArbre(Eleve *e, char *key, int *result);
int addEleve(Eleve *e, char *key, int value);
Arbre *createArbre(char *key, int value);
void freedom(Arbre *tree);
#endif // COMMON_H
