/**
*Inclusion des fichiers d'en-tête nécessaires.
*/ 

/**
 * @file main.c
 * @brief Programme principal pour gérer une HashMap.
 * 
 * Ce fichier contient le point d'entrée principal du programme qui démontre l'utilisation
 * d'une structure de données HashMap. Il inclut des opérations comme l'ajout, la mise à jour,
 * l'affichage, la suppression et la recherche dans la HashMap.
 */

#include "abr.h"
#include "listechainee.h"
#include "hashmap.h"

/**
 * @brief Point d'entrée principal du programme.
 * 
 * @return int Code de retour du programme.
 */

/// @brief  Point d'entrée principal du programme.
int main (){
    /// @brief  Création d'une nouvelle HashMap.
    HashMap *head=createHashMap();
    /// @brief  Déclaration de variables pour stocker des noms et des valeurs.
    char prenom[100000];
    int value=0;
    char commande[100];
    /// @brief  Initialisation de la HashMap avec des valeurs prédéfinies.
    char prenom1[100]="Alban";
    int value1=10;
    char prenom2[100]="Michell";
    int value2=12;;
    char prenom3[100]="Junio";
    int value3=56;
    char prenom4[100]="Mars";
    int value4=18;
    /// @brief  Ajout des valeurs prédéfinies à la HashMap.
    addHM(head,prenom1,value1);
    addHM(head,prenom2,value2);
    addHM(head,prenom3,value3);
    addHM(head,prenom4,value4);
    /// @brief  Message initial pour l'utilisateur.
    printf("type help if you need any information\n");
    /// @brief  Boucle principale pour traiter les commandes de l'utilisateur.
    do{
            /// @brief  Lecture de la commande de l'utilisateur.
            scanf("%s",commande);
             /// @brief  Traitement des différentes commandes.
        if(strcmp(commande,"help")==0){
            /// @brief  Affichage des commandes disponibles.
            printf("taper 'addHM' pour ajouter un coupler prenom valuer à la HashMap\n");
            printf("taper 'update' mettre a jour un couple valeur prénom\n");
            printf("taper 'display' pour afficher la HashMap\n");
            printf("taper 'remove' pour supprimer un coupler prenom valuer à la HashMap\n");
            printf("taper 'getHM' pour obtenir la valeur d'un prénom\n");
            printf("taper 'getsize' pour obtenir la taille de la Hashmap\n");
            printf("taper 'exit' pour sortir du programme\n");
        }
        else if(strcmp(commande,"addHM")==0){
            /// @brief  Ajout d'un nouveau couple nom/valeur à la HashMap.
            printf("donner un prenom\n");
            if(scanf("%6s",prenom)==1){
                printf("donner une valeur\n");
                if(scanf("%d",&value)==1){
                    if(value>4000000){
                        printf("la valeur maximum que l'on peut mettre est 4000000");
                    }
                    else{
                         if(addHM(head,prenom,value)==1){
                        printf("Couple prénom valeur ajoutée\n");
                    }
                    else{
                        printf("ERROR :Couple prénom valeur non ajoutée\n");
                    }
                    }
                }
                else {
                    printf("problème avec la valeur rentrée\n");
                }
            }
            else{
                printf("problème avec la prénom rentrée\n");
            }
        }
        else if(strcmp(commande,"update")==0){
            /// @brief  Mise à jour d'un couple nom/valeur dans la HashMap
            printf("donner le prenom dont voius voulez modifier la valeur \n");
            if(scanf("%s",prenom)==1){
                printf("donner une valeur\n");
                if(scanf("%d",&value)==1){
                    if(value>4000000){
                        printf("la valeur maximum que l'on peut mettre est 4000000");
                    }
                    else{
                        if(update(head,prenom,value)==1){
                        printf("Couple prénom valeur ajoutée\n");
                    }
                    else{
                        printf("ERROR :Couple prénom valeur non ajoutée\n");
                    }
                    }
                }
                else {
                    printf("problème avec la valeur rentrée\n");
                }
            }
            else{
                printf("problème avec la prénom rentrée\n");
            }
        }
        else if(strcmp(commande,"display")==0){
            /// @brief  Affichage de la HashMap.
           display(head->pRoot);
        }
        else if(strcmp(commande,"remove")==0){
            /// @brief Suppression d'un couple nom/valeur de la HashMap.
            printf("quel prenom voulez vous supprimer\n");
            if(scanf("%s",prenom)==1){
                if(removeHM(head,prenom)==1){
                printf("Couple prénom valeur retiré\n");
            }
                else{
                    printf("la suppresion n'a pas fonctionnée\n");
                }
            }
            else{
                printf("il y as une erreur avec le prénom que vous avez mis\n");
            }
        }
        else if(strcmp(commande,"getHM")==0){
            /// @brief  Obtention de la valeur associée à un nom dans la HashMap.
            printf("Quel nom vous voulez connaitre la valeur\n");
                if(scanf("%s",prenom)==1){
                    Eleve *e=getHM(head,prenom);
                    printf("La valeur de prénom choisis est :%d\n",e->value);
                }
                else{
                    printf("Il y as un problème avec le prénom choisis\n");
                }
            }
        else if (strcmp(commande,"getsize")==0){
            /// @brief  Affichage de la taille de la HashMap.
            printf("La taille de l'arbre est de :%d\n",sizeHM(head));
        }
        else{
            /// @brief  Message par défaut si la commande n'est pas reconnue.
            printf("Veuillez ecrire help si vous avez besoins d'aide\n");
        }
    }while(strcmp(commande,"exit")!=0);
    // Nettoyage et libération de la mémoire allouée pour la HashMap.
    freedom(head->pRoot);
    return 0;
}