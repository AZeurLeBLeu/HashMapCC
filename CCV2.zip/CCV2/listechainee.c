#include "listechainee.h"

/// @brief  Crée et initialise un nouvel élève.
Eleve *creationEleve(char *key, int value) {
    Eleve *e = malloc(sizeof(Eleve));  
    /// @brief  Allocation de mémoire pour un nouvel élève.
    if (e == NULL) {
        printf("Erreur d'allocation pour creationEleve\n");
        exit(EXIT_FAILURE);  
        /// @brief  Quitte le programme en cas d'échec d'allocation.
    }
    e->key = key;  
    /// @brief  Assignation de la clé.
    e->value = value;  
    /// @brief  Assignation de la valeur.
    e->fils = NULL;  
    /// @brief  Initialisation du pointeur fils à NULL.
    return e;  
    /// @brief  Retourne le nouvel élève.
}

/// @brief  Met à jour la valeur d'un élève dans l'arbre.
int updateArbre(Eleve *e, char *key, int value) {
    if (e == NULL) {
        printf("Valeur non mise à jour\n");
        return 0;
    }
    if (strcmp(e->key, key) == 0) {
        e->value = value;  
        /// @brief  Mise à jour de la valeur si la clé correspond.
        return 1;
    } else {
        return updateArbre(e->fils, key, value);  
        /// @brief  Continue la recherche récursivement.
    }
}

/// @brief  Supprime un élève de l'arbre et ajuste les liens.
Eleve *removeArbre(Eleve *e, char *key, int *result) {
    if (e == NULL) {
        *result = 0;
    } else if (strcmp(e->key, key) == 0) {
        Eleve *temp = e;  
        /// @brief  Stocke temporairement l'élément à supprimer.
        e = e->fils;  
        /// @brief  Réajuste le lien pour exclure l'élément supprimé.
        free(temp);  
        /// @brief  Libère la mémoire de l'élément supprimé.
        *result = 1;
    } else {
        e->fils = removeArbre(e->fils, key, result);  
        /// @brief  Continue la recherche récursivement.
    }
    return e;
}

/// @brief  Recherche un élève dans l'arbre par clé.
Eleve *searchArbre(Eleve *e, char *key) {
    if (e == NULL) {
        printf("clé non trouvée\n");
        return NULL;
    }
    if (strcmp(e->key, key) == 0) {
        return e;  
        /// @brief  Retourne l'élève si la clé correspond.
    } else {
        return searchArbre(e->fils, key);  
        /// @brief  Continue la recherche récursivement.
    }
}

/// @brief  Ajoute un nouvel élève à l'arbre.
int addEleve(Eleve *e, char *key, int value) {
    /// @brief  Vérifie si l'élève actuel est nul.
    if(e == NULL){
        printf("Erreur avec l'élève");
        return 0;
    }
    /// @brief  Vérifie si la clé existe déjà et ajoute un tag unique si nécessaire.
    /// @brief  (Votre code gère les clés en double en ajoutant un tag aléatoire)
    
    /// @brief  Parcourt la liste jusqu'à trouver la fin et ajoute le nouvel élève.
    while (e->fils != NULL) {
        /// @brief  (Votre code vérifie à nouveau pour les doublons)
        e = e->fils;
    }
    e->fils = creationEleve(key, value);  
    /// @brief  Ajoute le nouvel élève à la fin.
    return 1;
}

/// @brief  Affiche les éléments de la liste chaînée.
int displayFile(Eleve *e) {
    if (e == NULL) {
        return 1;
    } else {
        /// @brief  Affiche les informations de l'élève actuel.
        printf("La clé est %s\n", e->key);
        printf("La valeur est %d\n", e->value);
        return displayFile(e->fils);  // Continue l'affichage récursivement.
    }
}

/// @brief  Libère la mémoire allouée pour la liste chaînée.
int freedomFile(Eleve *e) {
    if (e == NULL) {
        return 1;
    }
    if (e->fils == NULL) {
        free(e);  
        /// @brief  Libère l'élève actuel.
        return 1;
    } else {
        freedomFile(e->fils);
        free(e);
        return 1;
    }
}
       

