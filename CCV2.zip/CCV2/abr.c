#include "abr.h"

/// @brief  Crée un nouvel arbre avec une clé et une valeur.
Arbre *createArbre(char *key, int value) {
    Arbre *a = malloc(sizeof(Arbre));  
    /// @brief  Allocation de mémoire pour un nouvel arbre.
    if (a == NULL) {
        printf("Erreur d'allocation pour createArbre\n");
        exit(EXIT_FAILURE);  
        /// @brief  Quitte le programme si l'allocation échoue.
    }
    a->hash = HashCode(key);  
    /// @brief  Calcule le code de hachage pour la clé.
    a->e = creationEleve(key, value);  
    /// @brief  Crée un nouvel élève et l'assigne à l'arbre.
    a->fg = NULL;  
    /// @brief  Initialise le fils gauche à NULL.
    a->fd = NULL;  
    /// @brief  Initialise le fils droit à NULL.
    return a;  
    /// @brief  Retourne le nouvel arbre.
}

/// @brief  Affiche les éléments de l'arbre.
void display(Arbre *head) {
    if (head == NULL)
        return;
    display(head->fg);  
    /// @brief  Affichage récursif du sous-arbre gauche.
    displayFile(head->e);  
    /// @brief  Affichage de l'élève.
    display(head->fd);  
    /// @brief  Affichage récursif du sous-arbre droit.
}

/// @brief  Libère la mémoire allouée pour l'arbre.
void freedom(Arbre *tree) {
    if (tree == NULL) {
        return;
    }
    freedom(tree->fg);  
    /// @brief  Libération récursive du sous-arbre gauche.
    freedomFile(tree->e);  
    /// @brief  Libération de l'élève.
    freedom(tree->fd);  
    /// @brief  Libération récursive du sous-arbre droit.
    free(tree);  
    /// @brief  Libération du nœud de l'arbre lui-même.
}

/// @brief  Ajoute un nouvel élève dans l'arbre.
int addNode(Arbre **tree, char *key, int value, int hash){
    /// @brief  Cas de base : si le pointeur d'arbre est NULL, crée un nouvel arbre.
    if (*tree == NULL) {
        *tree = createArbre(key, value);
        return 1;
    } 
    /// @brief  Si le code de hachage correspond, ajoute l'élève à cet arbre.
    else if (hash == (*tree)->hash) {
        addEleve((*tree)->e, key, value);
        return 1;
    } 
    /// @brief  Si le code de hachage est plus grand, ajoute récursivement au sous-arbre droit.
    else if (hash > (*tree)->hash) {
        return addNode(&(*tree)->fd, key, value, hash);
    } 
    /// @brief  Si le code de hachage est plus petit, ajoute récursivement au sous-arbre gauche.
    else if (hash < (*tree)->hash) {
        return addNode(&(*tree)->fg, key, value, hash);
    }
    return 0;
}

/// @brief  Met à jour la valeur d'un élève dans l'arbre.
int searchuHM(Arbre *tree, int hash, char *key, int value) {
    /// @brief  Vérifie si l'arbre contient le code de hachage recherché.
    if (tree == NULL) {
        printf("Valeur non mise à jour\n");
        return 0;
    }
    if (tree->hash == hash) {
        return updateArbre(tree->e, key, value);
    }
    /// @brief  Continue la recherche dans le sous-arbre approprié.
    return (tree->hash > hash) ? searchuHM(tree->fg, hash, key, value) : searchuHM(tree->fd, hash, key, value);
}

/// @brief  Supprime un élève de l'arbre.
int searchrHM(Arbre *tree, int hash, char *key) {
    if (tree == NULL) {
        return 0;
    }
    if (tree->hash == hash) {
        int result = 0;
        tree->e = removeArbre(tree->e, key, &result);
        return result;
    }
    /// @brief  Continue la recherche dans le sous-arbre approprié.
    return (tree->hash > hash) ? searchrHM(tree->fg, hash, key) : searchrHM(tree->fd, hash, key);
}


/// @brief  Recherche un élève dans l'arbre binaire de recherche.
Eleve *searchHM(Arbre *tree, int hash, char *key) {
    /// @brief  Cas de base : si le nœud actuel de l'arbre a un code de hachage qui correspond à celui recherché.
    if (tree->hash == hash) {
        /// @brief  Appelle la fonction searchArbre pour rechercher l'élève dans la liste chaînée à ce nœud.
        return searchArbre(tree->e, key);
    }

    /// @brief  Si le code de hachage recherché est inférieur au code de hachage du nœud actuel,
    /// @brief  continue la recherche dans le sous-arbre gauche.
    if (tree->hash > hash) {
        return searchHM(tree->fg, hash, key);
    }

    /// @brief  Si le code de hachage recherché est supérieur au code de hachage du nœud actuel,
    /// @brief  continue la recherche dans le sous-arbre droit.
    if (tree->hash < hash) {
        return searchHM(tree->fd, hash, key);
    }

    /// @brief  Dans le cas où aucun des cas ci-dessus ne correspond, renvoie l'élément actuel.
    /// @brief  Cette partie du code peut être atteinte si tous les éléments ont le même code de hachage.
    else {
        return tree->e;
    }
}
