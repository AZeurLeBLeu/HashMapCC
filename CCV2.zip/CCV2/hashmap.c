#include "hashmap.h"

/// @brief  Fonction pour calculer le code de hachage d'une chaîne de caractères.
int HashCode(char *ligne) {
    int Code = 0;
    /// @brief Parcourt chaque caractère de la chaîne.
    for (int i = 0; i < strlen(ligne); i++)
        Code = ligne[i] + 31 * Code;  
    /// @brief  Calcule le code de hachage.
    return Code % 101;  
    /// @brief  Modulo pour limiter la taille du code de hachage.
}

/// @brief  Crée et initialise une nouvelle HashMap.
HashMap *createHashMap() {
    /// @brief  Allocation de mémoire pour la HashMap.
    HashMap *head = malloc(sizeof(HashMap));
    if (head == NULL) {
        printf("Erreur d'allocation pour createHashMap\n");
        exit(EXIT_FAILURE);  
        /// @brief  Quitte le programme en cas d'erreur d'allocation.
    }
    /// @brief  Initialise les champs de la structure.
    head->pRoot = NULL;
    head->size = 0;
    return head;
}

/// @brief  Ajoute un nouvel élément à la HashMap.
int addHM(HashMap *head, char *key, int value) {
    /// @brief  Vérifie si le pointeur de HashMap est nul.
    if(head == NULL){
        printf("il y as une erreur, le pointeur de la Hashmap ne peut pas être nulle");
        return 0;
    }
    int hash = HashCode(key);  /// @brief  Calcule le code de hachage pour la clé.

    /// @brief  Appelle addNode pour ajouter l'élément.
    if (addNode(&(head->pRoot), key, value, hash) == 1) {
        head->size++;  
        /// @brief  Incrémente la taille de la HashMap.
        return 1;  
        /// @brief  Retourne 1 si l'ajout est réussi.
    }
    return 0;  
    /// @brief  Retourne 0 en cas d'échec.
}

/// @brief  Récupère un élément de la HashMap en fonction de la clé.
Eleve *getHM(HashMap *head, char *key) {
    int hash = HashCode(key);  
    /// @brief  Calcule le code de hachage pour la clé.
    return searchHM(head->pRoot, hash, key);  
    /// @brief  Recherche et renvoie l'élément.
}

/// @brief  Supprime un élément de la HashMap.
int removeHM(HashMap *head, char *key) {
    int hash = HashCode(key);  
    /// @brief  Calcule le code de hachage pour la clé.
    int result = searchrHM(head->pRoot, hash, key);  
    /// @brief  Effectue la suppression.
    if (result == 1) {
        head->size--;  
        /// @brief  Décrémente la taille de la HashMap.
    }
    return result;  
    /// @brief  Retourne le résultat de la suppression.
}

/// @brief  Retourne la taille de la HashMap.
int sizeHM(HashMap *head) {
/// @brief  Vérifie si le pointeur de HashMap est nul.
if(head == NULL){
printf("problème de pointeur");
return 0;
}
return head->size; /// @brief  Retourne la taille actuelle de la HashMap.
}

/// @brief  Met à jour la valeur d'un élément dans la HashMap.
int update(HashMap *head, char *key, int value) {
int hash = HashCode(key); 
/// @brief  Calcule le code de hachage pour la clé.
/// @brief  Appelle searchuHM pour mettre à jour la valeur.
return searchuHM(head->pRoot, hash, key, value);
}