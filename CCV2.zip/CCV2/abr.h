#ifndef ABR_H
#define ABR_H

#include "common.h"

Eleve *searchHM(Arbre *tree, int hash, char *key);

#endif // ABR_H
